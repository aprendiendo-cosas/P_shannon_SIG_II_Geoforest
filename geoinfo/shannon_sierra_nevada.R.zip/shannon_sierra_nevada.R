# Este script genera un mapa del índice de Shannon en cuadrículas de 250x250 m a partir de los daots de presencias de especies existentes en GBIF.

# 1. Establece directorio de trabajo
setwd("/Users/fjbonet/Library/CloudStorage/OneDrive-UniversidaddeCórdoba/4_docencia/SIG_II_geoforest_UCO/repos_actos_docentes/P_shannon_SIG_II_Geoforest/preparacion")

# 2. Instalar y cargar los paquetes necesarios
install.packages("sf")
library(sf)

install.packages("sqldf")
library(sqldf)

# 3. Importamos el archivo csv de GBIF con sus atributos geográficos
presencias <- read.csv("0118822-200613084148143.csv", header = TRUE, sep ="\t", dec = ".")

# 4. Convertimos la tabla importada a un objeto geográfico tipo sf
presencias_geo <- st_as_sf(presencias, coords = c("decimalLongitude", "decimalLatitude"), crs = 4326)

# 5. Reproyectamos la capa creada al sistema de coordenadas 23030 (UTM)
presencias_geo_23030 <- st_transform(presencias_geo, crs = 23030)

# 6. Creamos una malla de 250 m con la extensión y sistema de coordenadas de la capa de presencias
grid_250m <- st_make_grid(presencias_geo_23030, cellsize = c(250, 250))

# 7. Transformamos la malla obtenida (tipo sfc) a tipo espacial sf
grid_250m_sf <-st_sf(geometry = grid_250m)

# 8. Añadimos un campo llamado id_250 a la malla. Le incluimos valores secuenciales desde 1.
grid_250m_sf$id_250 <- seq(1, 67304, by = 1)

# 9. Asignamos a cada punto de presencia el código del cuadrado de la malla en el que está. Unión espacial.
presencias_x_grid <- st_join(presencias_geo_23030,left = FALSE, grid_250m_sf)

# 10. Extraemos la tabla de atributos de la capa de puntos creada y borramos todos los campos menos los dos que nos interesan. 
bio <- as.data.frame(presencias_x_grid)
bio <- bio[c('id_250', 'scientificName')]

# 11. Calcular el número de individuos por especie y por cuadrícula (num_ind_sp_cuad)
T_num_ind_sp_cuad<-sqldf("SELECT id_250, scientificName,  count(scientificName) num_ind_sp_cuad  FROM bio GROUP BY id_250, scientificName")

# 12. Calcular el número total de individuos por cuadrícula.
T_num_ind_cuad<-sqldf("SELECT id_250, sum(num_ind_sp_cuad) num_ind_cuad FROM T_num_ind_sp_cuad GROUP BY id_250")

# 13. Fusionar las tablas anteriores para calcular Pi
T_num_ind_sp_cuad_mas_num_ind_cuad<-sqldf("SELECT id_250, scientificName, num_ind_sp_cuad, num_ind_cuad FROM T_num_ind_sp_cuad LEFT JOIN T_num_ind_cuad USING(id_250)")

# 14. Calcular pi por especie y por cuadrícula.
T_num_ind_sp_cuad_mas_num_ind_cuad<-sqldf("SELECT id_250, scientificName, num_ind_sp_cuad, num_ind_cuad, (num_ind_sp_cuad*1.0/num_ind_cuad) pi FROM T_num_ind_sp_cuad_mas_num_ind_cuad")

# 15. Calcular el log2 pi por especie y por cuadrícula (log = ln). Log2(pi)=log(pi)/log(2)
T_num_ind_sp_cuad_mas_num_ind_cuad<-sqldf("SELECT id_250, scientificName, num_ind_sp_cuad, num_ind_cuad, pi, (log(pi)/log(2))*pi lnpi_pi FROM T_num_ind_sp_cuad_mas_num_ind_cuad")

# 16. Calcular H por cuadrícula
T_Shannon<-sqldf("SELECT id_250, sum(lnpi_pi)*-1 H FROM T_num_ind_sp_cuad_mas_num_ind_cuad GROUP BY id_250")

# 17. Fusionar la tabla que tiene el índice de Shannon con la malla de cuadrículas.
grid_250m_sf<-merge(x = grid_250m_sf, y = T_Shannon, by.x = "id_250", by.y = "id_250")

# 18. Exportamos la capa de la malla obtenida a un fichero de formas para visualizarlo en QGIS.
st_write(grid_250m_sf, "Shannon_250_sierra_nevada.shp", append=FALSE)